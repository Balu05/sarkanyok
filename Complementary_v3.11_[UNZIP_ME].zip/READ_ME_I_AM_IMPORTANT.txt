--------------------------------------------------------------------------------------------------
  ___ __  __ ____   ___  ____ _____  _    _   _ _____ 
 |_ _|  \/  |  _ \ / _ \|  _ \_   _|/ \  | \ | |_   _|
  | || |\/| | |_) | | | | |_) || | / _ \ |  \| | | |  
  | || |  | |  __/| |_| |  _ < | |/ ___ \| |\  | | |  
 |___|_|  |_|_|    \___/|_| \_\|_/_/   \_\_| \_| |_|  
 
 Installation:
 
 ---Don't forget to install "Optifine" for shader pack support before installing Complementary---
 
 Path 1: If you are NOT using big mods AND you are playing on 1.13.2 or higher:
   1) Select the ComplementaryResources as your resource pack (for many extra effects and fixes)
   2) If you want to, you can use a different PBR resource pack instead of ComplementaryResources
   3) Select the ComplementaryShaders as your shader pack
 
 Path 2: If you ARE using big mods, OR you're on 1.12.2 or below, OR you just want more fps:
   1) Completely ignore the ComplementaryResources
   2) Select the ComplementaryShaders as your shader pack
   3) Go to Shader Options and click "Profile" on the top right to enable the "Compatibility Mode"

--------------------------------------------------------------------------------------------------
 That's it!
 
 If you encounter mod issues, please check out this mod issue fix list: https://justpaste.it/60cgu
 For help, questions and more, feel free to join my Discord server: https://discord.gg/A6faFYt
 Complementary is developed with passion and I really hope you enjoy it as much as I do.
 
 Sincerely,
 EminGT
--------------------------------------------------------------------------------------------------